package com.springjdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

import com.springjdbc.daoimpl.Studentdaoimpl;
import com.springjdbc.entity.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//       ApplicationContext context=new 
//    		   ClassPathXmlApplicationContext("com/springjdbc/config.xml");
       ApplicationContext context=new AnnotationConfigApplicationContext(Config.class);
    	Studentdaoimpl simpl=(Studentdaoimpl) context.getBean("simpl");
 //      String q="insert into student values(?,?)";
//       String q="update student set name=? where id=?";
 //      		String q="delete from student where id=?";
  //     int x=template.update(q,3,"vijay");
  //     System.out.println(x+" row inserted");
//       String q="select * from student where id=?";
//       Student student=template.queryForObject(q,new RowMapperImpl(),3);
//       
//       
//       System.out.println(student);
       
//       String q="select * from student";
//       List<Student> ls=template.query(q, new RowMapperImpl());
//       System.out.println(ls);
       
       Student student=new Student(1,"viki");
//       simpl.addStudent(student);
//       simpl.updateStudent(student);
       simpl.deleteStudent(student);
       
       
    }
}
