package com.springjdbc.dao;

import com.springjdbc.entity.Student;

public interface Studentdao {
public void addStudent(Student student);
public void updateStudent(Student student);
public void deleteStudent(Student student);
}
