package com.springjdbc.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.springjdbc.dao.Studentdao;
import com.springjdbc.entity.Student;

@Component("simpl")
public class Studentdaoimpl implements Studentdao {
	
	@Autowired
	private JdbcTemplate template;
	public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	public Studentdaoimpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Studentdaoimpl(JdbcTemplate template) {
		super();
		this.template = template;
	}
	@Override
	public void addStudent(Student student) {
		// TODO Auto-generated method stub
		String q="insert into student values(?,?)";
		int x=template.update(q,student.getId(),student.getName());
		if(x>0) {
			System.out.println("data added");
		}
		else {
			System.out.println("not added");
		}
		
	}
	@Override
	public void updateStudent(Student student) {
		// TODO Auto-generated method stub
		String q="update student set name=? where id=?";
		int x=template.update(q,student.getName(),student.getId());
		if(x>0) {
			System.out.println("data updated");
		}
		else {
			System.out.println("not updated");
		}
		
		
	}
	@Override
	public void deleteStudent(Student student) {
		// TODO Auto-generated method stub
		String q="delete from student where id=?";
		int x=template.update(q,student.getId());
		if(x>0) {
			System.out.println("data deleted");
		}
		else {
			System.out.println("not deleted");
		}
		
		
	}
	

}
